﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EMS.Data;
using EMS.Models;
using System.Text.Json;
using Newtonsoft.Json;
using System.Text;

namespace EMS.Controllers
{
    public class Departments1Controller : Controller
    {
        private readonly EMSContext _context;
        private readonly HttpClient _client;
        Uri baseAddress = new Uri("http://localhost:5112/api/");

        public Departments1Controller(EMSContext context)
        {
            _context = context;
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
        }

        // GET: Departments1
        public async Task<IActionResult> Index()
        {
            List<Department> departments = new List<Department>();

            HttpResponseMessage response = await _client.GetAsync(_client.BaseAddress + "Department/GetDepartment");

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                departments = JsonConvert.DeserializeObject<List<Department>>(data);
            }

            return View(departments);
        }

        // GET: Departments1/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Department department = null;
            string requestUri = $"Department/GetDepartment/{id}";
            HttpResponseMessage response = await _client.GetAsync(requestUri);

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                department = JsonConvert.DeserializeObject<Department>(data);
            }


            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // GET: Departments1/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Departments1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DepartmentID,DepartmentName")] Department department)
        {
            if (!ModelState.IsValid)
            {
                return View(department);
            }
            string url = "Department/PostDepartment";

            var jsonContent = new StringContent(JsonConvert.SerializeObject(department), Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _client.PostAsync(url, jsonContent);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            string errorMessage = await response.Content.ReadAsStringAsync();
            ModelState.AddModelError(string.Empty, $"Error occurred while creating department: {response.StatusCode} - {errorMessage}");
            return View(department);
        }

        // GET: Departments1/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            string url = $"Department/GetDepartment/{id}";
            HttpResponseMessage response = await _client.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                Department department = JsonConvert.DeserializeObject<Department>(data);

                if (department == null)
                {
                    return NotFound();
                }
                return View(department);
            }

            return View();
        }

        // POST: Departments1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DepartmentID,DepartmentName")] Department department)
        {
            if (!ModelState.IsValid)
            {
                return View(department);
            }

            string url = $"Department/PutDepartment/{id}";
            var jsonContent = new StringContent(JsonConvert.SerializeObject(department), Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _client.PutAsync(url, jsonContent);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            return View(department);
        }

        // GET: Departments1/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Department department = null;
            string requestUri = $"Department/GetDepartment/{id}";
            HttpResponseMessage response = await _client.GetAsync(requestUri);

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                department = JsonConvert.DeserializeObject<Department>(data);
            }

            if (department == null)
            {
                return NotFound();
            }

            return View(department);
        }

        // POST: Departments1/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            string requestUri = $"Department/DeleteDepartment/{id}";
            HttpResponseMessage response = await _client.DeleteAsync(requestUri);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }
            ModelState.AddModelError("", "Unable to delete the employee. Please try again.");
            return View();
        }
    }
}
