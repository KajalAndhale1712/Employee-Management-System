﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EMS.Data;
using EMS.Models;

namespace EMS.Controllers   
{                                                                           
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly EMSContext _context;
        //private readonly HttpClient _httpClient;

        public EmployeesController(EMSContext context)
        {
            _context = context;
           // _httpClient = httpClient;
        }

        // GET: api/Employees
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employee>>> GetEmployee()
        {
            return await _context.Employee.ToListAsync();
        }

        // GET: api/Employees/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetEmployee(int id)
        {
            var employee = await _context.Employee.FindAsync(id);

            if (employee == null)
            {
                return NotFound();
            }

            return employee;
        }

        // PUT: api/Employees/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmployee(int id, Employee employee)
        {
            if (employee == null)
            {
                return BadRequest("Employee data is required.");
            }

            var existingEmployee = await _context.Employee.FindAsync(id);
            if (existingEmployee == null)
            {
                return NotFound();
            }

            existingEmployee.Name = employee.Name;
            
            existingEmployee.Email = employee.Email;
            existingEmployee.Phone = employee.Phone;

            existingEmployee.DepartmentID = employee.DepartmentID;
            await _context.SaveChangesAsync();

            return NoContent();
        }   

        // POST: api/Employees
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Emp>> PostEmployee(Emp emp)
        {
            var employee = new Employee
            {
                EmployeeID = emp.EmployeeID,
                Name = emp.Name,
                Email = emp.Email,
               Phone = emp.Phone,   
               DepartmentID = emp.DepartmentID
            };
            _context.Employee.Add(employee);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetEmployee), new { id = employee.EmployeeID }, employee);
        }

        // DELETE: api/Employees/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var employee = await _context.Employee.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }

            _context.Employee.Remove(employee);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employee.Any(e => e.EmployeeID == id);
        }
    }
}

/*{
    "EmployeeID":1, 
    "Name":"kajal",
        "Email":"kajal111@gmail.com",
        "Phone":2435678431,
        "DepartmentID":1



}*/