﻿using System;
using System.Collections.Generic;
using System.Linq;      
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EMS.Data;
using EMS.Models;
using EMS.Controllers;
using System.Text.Json;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;

namespace EMS.Controllers
{
    public class Employees1Controller : Controller
    {
        private readonly EMSContext _context;
        Uri baseAddress = new Uri("http://localhost:5112/api/");
        private readonly HttpClient _client;

        public Employees1Controller(EMSContext context)
        {
            _client = new HttpClient();
            _client.BaseAddress = baseAddress;
            _context = context;

        }

        // GET: Employees1
        public async Task<IActionResult> Index()
        {
            List<Employee> employees = new List<Employee>();

            HttpResponseMessage response = await _client.GetAsync(_client.BaseAddress + "Employee/GetMyEntities");

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                employees = JsonConvert.DeserializeObject<List<Employee>>(data);
            }

            return View(employees);
        }

        // GET: Employees1/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            Employee employee = null;
            string url = $"Employee/GetMyEntity/{id}";
            HttpResponseMessage response = await _client.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                employee = JsonConvert.DeserializeObject<Employee>(data);
            }

            if (employee == null)
            {
                return NotFound();
            }
            return View();
        }

        // GET: Employees1/Create
        public IActionResult Create()
        {
            ViewData["DepartmentID"] = new SelectList(_context.Department, "DepartmentID", "DepartmentID");
            return View();
        }

        // POST: Employees1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EmployeeID,Name,Email,Phone,DepartmentID")] Emp employee)
        {
            if (!ModelState.IsValid)
            {
                ViewData["DepartmentID"] = new SelectList(await _context.Department.ToListAsync(), "DeptId", "DepartmentID", employee.DepartmentID);
                return View(employee);
            }
            string url = "Employee/PostEmployee";

            var jsonContent = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _client.PostAsync(url, jsonContent);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            string errorMessage = await response.Content.ReadAsStringAsync();
            ModelState.AddModelError(string.Empty, $"Error occurred while creating employee: {response.StatusCode} - {errorMessage}");

            return View(employee);


            ViewData["DepartmentID"] = new SelectList(_context.Department, "DepartmentID", "DepartmentID", employee.DepartmentID);
            return View(employee);
        }

        // GET: Employees1/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            Employee employee = null;
            string url = $"Employee/GetMyEntity/{id}";
            HttpResponseMessage response = await _client.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                employee = JsonConvert.DeserializeObject<Employee>(data);
            }

            if (employee == null)
            {
                return NotFound();
            }
            ViewData["DepartmentID"] = new SelectList(_context.Department, "DepartmentID", "DepartmentID", employee.DepartmentID);
            return View(employee);
        }

        // POST: Employees1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EmployeeID,Name,Email,Phone,DepartmentID")] Employee employee)
        {

            if (!ModelState.IsValid)
            {
                ViewData["DepartmentID"] = new SelectList(_context.Department, "DepartmentID", "DepartmentID", employee.DepartmentID);
                return View(employee);
            }
            string url = $"Employee/PutMyEntity/{id}";
            var jsonContent = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");
            HttpResponseMessage response = await _client.PutAsync(url, jsonContent);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: Employees1/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }


            Employee employee = null;
            string requestUri = $"Employee/GetMyEntity/{id}";
            HttpResponseMessage response = await _client.GetAsync(requestUri);

            if (response.IsSuccessStatusCode)
            {
                string data = await response.Content.ReadAsStringAsync();
                employee = JsonConvert.DeserializeObject<Employee>(data);
            }
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // POST: Employees1/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            string requestUri = $"Employee/DeleteMyEntity/{id}";
            HttpResponseMessage response = await _client.DeleteAsync(requestUri);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            // Handle error scenario if the delete operation fails
            ModelState.AddModelError("", "Unable to delete the employee. Please try again.");
            return View();
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employee.Any(e => e.EmployeeID == id);
        }
    }
}
