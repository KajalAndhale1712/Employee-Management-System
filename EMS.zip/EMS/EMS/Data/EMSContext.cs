﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using EMS.Models;

namespace EMS.Data
{
    public class EMSContext : DbContext
    {
        public EMSContext (DbContextOptions<EMSContext> options)
            : base(options)
        {
        }

        public DbSet<EMS.Models.Department> Department { get; set; } = default!;
        public DbSet<EMS.Models.Employee> Employee { get; set; } = default!;
        public DbSet<EMS.Models.Login> Login { get; set; } = default!;
        public DbSet<EMS.Models.Registration> Registration { get; set; } = default!;
    }
}
