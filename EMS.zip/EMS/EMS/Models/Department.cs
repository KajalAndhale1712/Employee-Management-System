﻿using System.ComponentModel.DataAnnotations;

namespace EMS.Models
{
    public class Department
    {
        [Key]
        public int DepartmentID { get; set; }

        [StringLength(100)]
        public string DepartmentName { get; set; }

        public ICollection<Employee> Employees { get; set; }=new List<Employee>();
    }
}
