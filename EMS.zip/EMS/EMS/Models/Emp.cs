﻿using System.ComponentModel.DataAnnotations;

namespace EMS.Models
{
    public class Emp
    {
        
            [Key]
            public int EmployeeID { get; set; }
            public string Name { get; set; }
            public string Email { get; set; }
            public string Phone { get; set; }
         
            public int DepartmentID { get; set; }

        
    }
}
