﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EMS.Models
{
    public class Employee
    {

        [Key]
        public int EmployeeID { get; set; }

        [StringLength(100)]
        public string Name { get; set; }

        [StringLength(100)]
        public string Email { get; set; }

        [StringLength(20)]
        public string Phone { get; set; }

        [ForeignKey("Department")]
        public int DepartmentID { get; set; } 

        public virtual Department Department { get; set; }
    }
}
